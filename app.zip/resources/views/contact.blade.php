@extends('layouts.app')
@section('title','Contact page')
@section('content')
        <h1>Contact page</h1>
        <p>You are contact</p>
@stop