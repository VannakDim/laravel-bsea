@extends('layouts.app')
@section('title','Contact page')
@section('content')
<div class="container-fluit bg-primary hero-header">
        <h1>About page</h1>
        <p>This is about page</p>
</div>
@stop