<?php $__env->startSection('title','Contact page'); ?>
<?php $__env->startSection('content'); ?>
        <h1>Contact page</h1>
        <p>You are contact</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/demo/resources/views/contact.blade.php ENDPATH**/ ?>