<?php $__env->startSection('title','Contact page'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluit bg-primary hero-header">
        <h1>About page</h1>
        <p>This is about page</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/demo/resources/views/about.blade.php ENDPATH**/ ?>